#!/bin/bash
# properties = {properties}

set -e

echo "hostname: ${{HOSTNAME}}"

{exec_job}
